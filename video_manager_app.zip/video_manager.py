# -*- coding: utf-8 -*-
import sys, os, re
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QComboBox, QTextEdit, QProgressBar,
    QDialog, QFormLayout, QDialogButtonBox, QMessageBox, QSplashScreen, QAction, QMenuBar
)
from PyQt5.QtCore import QThread, pyqtSignal, Qt, QSettings, QTimer, QRect
from PyQt5.QtGui import QPixmap, QPainter, QColor, QFont, QGuiApplication, QIcon
import yt_dlp

APP_ORG = "M01"
APP_NAME = "VideoManager"

# ---------- i18n ----------
I18N = {
    "en": {
        "app_title": "Video Manager",
        "label_url": "URL:",
        "placeholder_url": "Paste link here (YouTube, TikTok, X, ...)",
        "label_outdir": "Save to:",
        "choose": "Browse...",
        "label_quality": "Quality:",
        "download": "Download Video + Audio",
        "starting": "Starting... Video and audio will be merged (requires FFmpeg).",
        "saved": "Saved to: {path}",
        "error": "Error: {msg}",
        "settings": "Settings",
        "language": "Language",
        "theme": "Theme",
        "apply_restart": "Changes require restart to take effect. Restart now?",
        "light": "Light (White)",
        "dark": "Dark (Black)",
        "english": "English",
        "arabic": "Arabic",
        "splash_madeby": "Made by M01_1 with ChatGPT",
        "splash_loading": "Loading...",
        "pref_quality_best": "Best Quality",
    },
    "ar": {
        "app_title": "فيديو مانجر",
        "label_url": "الرابط:",
        "placeholder_url": "ألصق الرابط هنا (YouTube, TikTok, X, ...)",
        "label_outdir": "مكان الحفظ:",
        "choose": "اختيار...",
        "label_quality": "الجودة:",
        "download": "تحميل فيديو + صوت",
        "starting": "يبدأ التحميل... سيتم دمج الفيديو مع الصوت تلقائيًا (يتطلب FFmpeg).",
        "saved": "تم الحفظ: {path}",
        "error": "حدث خطأ: {msg}",
        "settings": "الإعدادات",
        "language": "اللغة",
        "theme": "اللون",
        "apply_restart": "التغييرات تحتاج لإعادة تشغيل لتطبيقها. هل تريد إعادة التشغيل الآن؟",
        "light": "أبيض (فاتح)",
        "dark": "أسود (داكن)",
        "english": "الإنجليزية",
        "arabic": "العربية",
        "splash_madeby": "صنع من M01_1 مع شات GPT",
        "splash_loading": "جاري التحميل...",
        "pref_quality_best": "أفضل جودة",
    }
}

QUALITY_PRESETS = [
    ("best", "bv*+ba/b"),
    ("1080p", "bv*[height<=1080]+ba/b[height<=1080]"),
    ("720p", "bv*[height<=720]+ba/b[height<=720]"),
    ("480p", "bv*[height<=480]+ba/b[height<=480]"),
    ("360p", "bv*[height<=360]+ba/b[height<=360]"),
]

def sanitize_filename(name: str) -> str:
    return re.sub(r'[\\/*?:"<>|]', '_', name)

def restart_app():
    python = sys.executable
    os.execl(python, python, *sys.argv)

# ---------- Worker Thread ----------
class DownloadWorker(QThread):
    log = pyqtSignal(str)
    progress = pyqtSignal(int)
    done = pyqtSignal(str, str)
    error = pyqtSignal(str)

    def __init__(self, url, outdir, fmt):
        super().__init__()
        self.url = url.strip()
        self.outdir = outdir
        self.format = fmt

    def _hook(self, d):
        try:
            if d.get('status') == 'downloading':
                pct_str = d.get('_percent_str', '0.0%').strip().replace('%','')
                pct = int(float(pct_str)) if pct_str else 0
                self.progress.emit(pct)
            elif d.get('status') == 'finished':
                self.progress.emit(100)
        except Exception:
            pass

    def run(self):
        if not self.url:
            self.error.emit("Empty URL.")
            return
        if not os.path.isdir(self.outdir):
            self.error.emit("Output directory does not exist.")
            return

        ydl_opts = {
            'format': self.format,
            'outtmpl': os.path.join(self.outdir, '%(title)s.%(ext)s'),
            'merge_output_format': 'mp4',
            'postprocessors': [
                {'key': 'FFmpegVideoRemuxer', 'preferedformat': 'mp4'}
            ],
            'noprogress': True,
            'progress_hooks': [self._hook],
            'retries': 5,
            'concurrent_fragment_downloads': 4,
        }
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(self.url, download=True)
                title = sanitize_filename(info.get('title','video'))
                target = os.path.join(self.outdir, f"{title}.mp4")
                if not os.path.isfile(target):
                    target = ydl.prepare_filename(info)
                self.done.emit(title, target)
        except Exception as e:
            self.error.emit(str(e))

# ---------- Settings Dialog ----------
class SettingsDialog(QDialog):
    def __init__(self, parent=None, lang="en", theme="dark"):
        super().__init__(parent)
        self.setModal(True)
        self.lang = lang
        self.theme = theme
        self.setWindowTitle(I18N[lang]["settings"])

        form = QFormLayout()

        self.lang_box = QComboBox()
        self.lang_box.addItem(I18N[lang]["english"], "en")
        self.lang_box.addItem(I18N[lang]["arabic"], "ar")
        idx = 0 if lang == "en" else 1
        self.lang_box.setCurrentIndex(idx)
        form.addRow(I18N[lang]["language"], self.lang_box)

        self.theme_box = QComboBox()
        self.theme_box.addItem(I18N[lang]["dark"], "dark")
        self.theme_box.addItem(I18N[lang]["light"], "light")
        self.theme_box.setCurrentIndex(0 if theme == "dark" else 1)
        form.addRow(I18N[lang]["theme"], self.theme_box)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

        self.setLayout(form)

    def values(self):
        return self.lang_box.currentData(), self.theme_box.currentData()

# ---------- Main App ----------
class App(QWidget):
    def __init__(self, lang="en", theme="dark"):
        super().__init__()
        self.lang = lang
        self.theme = theme
        self.setWindowTitle(I18N[lang]["app_title"])
        self.setGeometry(200, 200, 760, 380)
        self.setWindowIcon(QIcon("vm.png"))  # استخدام الأيقونة الجديدة

        self.apply_theme(theme)

        self.menu = QMenuBar(self)
        act_settings = QAction(I18N[lang]["settings"], self)
        act_settings.triggered.connect(self.open_settings)
        self.menu.addAction(act_settings)

        main = QVBoxLayout()
        main.setMenuBar(self.menu)

        url_row = QHBoxLayout()
        url_row.addWidget(QLabel(I18N[lang]["label_url"]))
        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText(I18N[lang]["placeholder_url"])
        url_row.addWidget(self.url_edit)
        main.addLayout(url_row)

        out_row = QHBoxLayout()
        out_row.addWidget(QLabel(I18N[lang]["label_outdir"]))
        self.out_edit = QLineEdit(os.path.expanduser("~"))
        out_row.addWidget(self.out_edit)
        browse = QPushButton(I18N[lang]["choose"])
        browse.clicked.connect(self.choose_dir)
        out_row.addWidget(browse)
        main.addLayout(out_row)

        q_row = QHBoxLayout()
        q_row.addWidget(QLabel(I18N[lang]["label_quality"]))
        self.q_combo = QComboBox()
        self.q_combo.addItem(I18N[lang]["pref_quality_best"], QUALITY_PRESETS[0][1])
        for label, fmt in QUALITY_PRESETS[1:]:
            self.q_combo.addItem(label, fmt)
        q_row.addWidget(self.q_combo)
        main.addLayout(q_row)

        btn_row = QHBoxLayout()
        self.dl_btn = QPushButton(I18N[lang]["download"])
        self.dl_btn.clicked.connect(self.start_download)
        btn_row.addWidget(self.dl_btn)
        main.addLayout(btn_row)

        self.pbar = QProgressBar()
        self.pbar.setValue(0)
        main.addWidget(self.pbar)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        main.addWidget(self.log)

        self.setLayout(main)
        self.worker = None

    def apply_theme(self, theme):
        if theme == "dark":
            self.setStyleSheet("""
                QWidget { background: #0f1115; color: #e6e6e6; font-size: 14px; }
                QLineEdit, QTextEdit { background: #151821; color: #e6e6e6; border: 1px solid #2a2f3a; }
                QPushButton { background: #1f2430; border: 1px solid #343b4a; padding: 6px 10px; }
                QPushButton:hover { background: #262c3a; }
                QComboBox { background: #1f2430; border: 1px solid #343b4a; padding: 4px; }
                QProgressBar { border: 1px solid #343b4a; text-align: center; }
                QProgressBar::chunk { background-color: #3b82f6; }
                QMenuBar { background: #0f1115; }
                QMenuBar::item { background: transparent; padding: 6px 10px; }
                QMenuBar::item:selected { background: #1f2430; }
            """)
        else:
            self.setStyleSheet("")

    def choose_dir(self):
        d = QFileDialog.getExistingDirectory(self, I18N[self.lang]["choose"], self.out_edit.text())
        if d:
            self.out_edit.setText(d)

    def start_download(self):
        url = self.url_edit.text().strip()
        fmt = self.q_combo.currentData()
        outdir = self.out_edit.text().strip()

        self.log.clear()
        self.log.append(I18N[self.lang]["starting"])
        self.pbar.setValue(0)
        self.dl_btn.setEnabled(False)

        self.worker = DownloadWorker(url, outdir, fmt)
        self.worker.progress.connect(self.pbar.setValue)
        self.worker.done.connect(self.on_done)
        self.worker.error.connect(self.on_error)
        self.worker.start()

    def on_done(self, title, path):
        self.dl_btn.setEnabled(True)
        self.pbar.setValue(100)
        self.log.append(I18N[self.lang]["saved"].format(path=path))

    def on_error(self, msg):
        self.dl_btn.setEnabled(True)
        self.log.append(I18N[self.lang]["error"].format(msg=msg))

    def open_settings(self):
        settings = QSettings(APP_ORG, APP_NAME)
        lang = settings.value("lang", "en")
        theme = settings.value("theme", "dark")
        dlg = SettingsDialog(self, lang, theme)
        if dlg.exec_() == QDialog.Accepted:
            new_lang, new_theme = dlg.values()
            changed = (new_lang != lang) or (new_theme != theme)
            if changed:
                settings.setValue("lang", new_lang)
                settings.setValue("theme", new_theme)
                reply = QMessageBox.question(self, "Restart",
                                             I18N[lang]["apply_restart"],
                                             QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
                if reply == QMessageBox.Yes:
                    restart_app()

# ---------- Splash ----------
def build_splash_pixmap(theme, lang):
    scale = QGuiApplication.primaryScreen().devicePixelRatio()
    w, h = 460, 260
    pm = QPixmap(w, h)
    pm.fill(Qt.transparent)
    painter = QPainter(pm)
    painter.setRenderHint(QPainter.Antialiasing, True)

    bg = QColor("#0f1115") if theme == "dark" else QColor("#f2f2f2")
    fg = QColor("#e6e6e6") if theme == "dark" else QColor("#1a1a1a")
    accent = QColor("#3b82f6")

    rect = QRect(0, 0, w, h)
    painter.setBrush(bg)
    painter.setPen(Qt.NoPen)
    painter.drawRoundedRect(rect, 20, 20)

    painter.setPen(fg)
    font = QFont()
    font.setPointSize(14)
    font.setBold(True)
    painter.setFont(font)
    title = I18N[lang]["splash_madeby"]
    painter.drawText(rect.adjusted(20, 90, -20, -130), Qt.AlignCenter, title)

    font2 = QFont()
    font2.setPointSize(11)
    painter.setFont(font2)
    painter.setPen(accent)
    painter.drawText(rect.adjusted(20, 140, -20, -80), Qt.AlignCenter, I18N[lang]["splash_loading"])

    painter.end()
    pm.setDevicePixelRatio(scale)
    return pm

def show_splash(theme, lang):
    pm = build_splash_pixmap(theme, lang)
    splash = QSplashScreen(pm, Qt.WindowStaysOnTopHint)
    splash.setWindowIcon(QIcon("vm.png"))  # أيقونة الشعار في السبلّاش أيضًا
    splash.show()
    return splash

# ---------- Main ----------
def main():
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    app = QApplication(sys.argv)
    settings = QSettings(APP_ORG, APP_NAME)

    lang = settings.value("lang", None)
    theme = settings.value("theme", None)

    if lang is None:
        lang = "en"
        settings.setValue("lang", lang)

    if theme is None:
        theme = "dark"
        settings.setValue("theme", theme)

    splash = show_splash(theme, lang)
    QTimer.singleShot(1100, splash.close)

    w = App(lang=lang, theme=theme)
    QTimer.singleShot(1200, w.show)

    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
